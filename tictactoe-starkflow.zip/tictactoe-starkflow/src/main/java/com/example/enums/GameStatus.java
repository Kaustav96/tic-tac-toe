package com.example.enums;

/**
 * Created by pdybka on 21.06.16.
 */
public enum GameStatus {
    WAITS_FOR_PLAYER,
    IN_PROGRESS,
    FIRST_PLAYER_WON,
    SECOND_PLAYER_WON,
    TIE,
    TIMEOUT
}
