package com.example.enums;

/**
 * Created by pdybka on 21.06.16.
 */
public enum Piece {
    X,
    O
}
